import { useCallback, useEffect, useRef, useState } from 'react'
import { trackEvent } from '../lib/eventTracker'

export type AudioAdviceButtonProps = {
  script?: string
  audioUrl?: string
  label?: string
  onPlayed?: () => void
  compact?: boolean
}

const DEFAULT_LABEL = 'Nghe tư vấn'
const STOP_LABEL = 'Dừng'
const PLAYBACK_ERROR_MESSAGE =
  'Không phát được audio, bạn có thể đọc phần tư vấn bên dưới.'

function canUseAudio(): boolean {
  return typeof window !== 'undefined' && typeof Audio !== 'undefined'
}

function canUseSpeechSynthesis(): boolean {
  return (
    typeof window !== 'undefined' &&
    'speechSynthesis' in window &&
    typeof window.speechSynthesis.speak === 'function'
  )
}

export default function AudioAdviceButton({
  script = '',
  audioUrl,
  label = DEFAULT_LABEL,
  onPlayed,
  compact = false,
}: AudioAdviceButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null)
  const usingSpeechRef = useRef(false)

  const releasePlaybackResources = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
      audioRef.current.onended = null
      audioRef.current.onerror = null
      audioRef.current = null
    }

    if (canUseSpeechSynthesis()) {
      window.speechSynthesis.cancel()
      usingSpeechRef.current = false
      utteranceRef.current = null
    }
  }, [])

  const stopPlayback = useCallback(() => {
    releasePlaybackResources()
    setIsPlaying(false)
  }, [releasePlaybackResources])

  const handlePlaybackError = useCallback(() => {
    stopPlayback()
    setErrorMessage(PLAYBACK_ERROR_MESSAGE)
  }, [stopPlayback])

  const playWithAudioElement = useCallback(async () => {
    if (!audioUrl || !canUseAudio()) {
      handlePlaybackError()
      return
    }

    const audio = new Audio(audioUrl)
    audioRef.current = audio

    audio.onended = () => {
      audioRef.current = null
      setIsPlaying(false)
    }

    audio.onerror = () => {
      handlePlaybackError()
    }

    try {
      await audio.play()
      setIsPlaying(true)
      setErrorMessage(null)
      trackEvent('tts_played', { source: 'audio' })
      onPlayed?.()
    } catch {
      handlePlaybackError()
    }
  }, [audioUrl, handlePlaybackError, onPlayed])

  const playWithSpeechSynthesis = useCallback(() => {
    if (!canUseSpeechSynthesis()) {
      handlePlaybackError()
      return
    }

    if (!script.trim()) {
      handlePlaybackError()
      return
    }

    try {
      const utterance = new SpeechSynthesisUtterance(script)
      utterance.lang = 'vi-VN'
      utteranceRef.current = utterance
      usingSpeechRef.current = true

      utterance.onstart = () => {
        setIsPlaying(true)
        setErrorMessage(null)
        trackEvent('tts_played', { source: 'speechSynthesis' })
        onPlayed?.()
      }

      utterance.onend = () => {
        usingSpeechRef.current = false
        utteranceRef.current = null
        setIsPlaying(false)
      }

      utterance.onerror = () => {
        handlePlaybackError()
      }

      window.speechSynthesis.cancel()
      window.speechSynthesis.speak(utterance)
    } catch {
      handlePlaybackError()
    }
  }, [script, handlePlaybackError, onPlayed])

  const startPlayback = useCallback(() => {
    setErrorMessage(null)

    if (audioUrl) {
      void playWithAudioElement()
    } else {
      playWithSpeechSynthesis()
    }
  }, [audioUrl, playWithAudioElement, playWithSpeechSynthesis])

  const handleClick = () => {
    if (isPlaying) {
      stopPlayback()
      return
    }

    startPlayback()
  }

  useEffect(() => {
    releasePlaybackResources()
  }, [script, audioUrl, releasePlaybackResources])

  useEffect(() => {
    return () => {
      releasePlaybackResources()
    }
  }, [releasePlaybackResources])

  const buttonLabel = isPlaying ? STOP_LABEL : label

  const buttonClassName = compact
    ? 'inline-flex min-h-11 items-center justify-center rounded-md border border-tertiary bg-white px-3 py-1.5 text-[11px] text-ink hover:bg-sand'
    : 'inline-flex h-11 w-full items-center justify-center rounded-md border border-line bg-white text-sm text-ink hover:bg-sand'

  return (
    <div className="flex flex-col gap-1.5">
      <button
        type="button"
        onClick={handleClick}
        aria-pressed={isPlaying}
        aria-label={buttonLabel}
        className={buttonClassName}
      >
        {buttonLabel}
      </button>

      {errorMessage ? (
        <p className="text-[11px] leading-snug text-muted" role="status">
          {errorMessage}
        </p>
      ) : null}
    </div>
  )
}
