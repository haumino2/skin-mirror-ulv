import type { ReactNode } from 'react'
import { mockWatsonPromo, type WatsonPromo } from '../data/promoConfig'
import { formatConcernList, getConcernLabel } from '../data/vietnameseSkinGlossary'
import type {
  RoutineRecommendation,
  SkinAnalysisResult,
  SkinGoal,
} from '../types/skinMirror'

export type BAHandoffViewProps = {
  skinResult?: SkinAnalysisResult
  recommendation?: RoutineRecommendation
  promo?: WatsonPromo
  onBack?: () => void
}

const SKIN_TYPE_LABELS: Record<string, string> = {
  oily: 'da dầu',
  dry: 'da khô',
  combination: 'da hỗn hợp',
  normal: 'da thường',
}

const GOAL_LABELS: Record<SkinGoal, string> = {
  hydrate: 'cấp ẩm',
  reduce_oil: 'giảm dầu',
  calm: 'làm dịu',
  smooth_texture: 'cải thiện texture',
}

function formatSkinType(skinType: string): string {
  const key = skinType.trim().toLowerCase()
  return SKIN_TYPE_LABELS[key] ?? skinType
}

function buildBaPitch(
  skinResult: SkinAnalysisResult,
  recommendation?: RoutineRecommendation,
): string {
  const skinType = formatSkinType(skinResult.skinType)
  const primaryConcern = skinResult.concerns[0]
    ? getConcernLabel(skinResult.concerns[0])
    : 'chưa rõ'
  const goal = recommendation?.goal
    ? GOAL_LABELS[recommendation.goal]
    : 'cân bằng da'
  const firstProduct =
    recommendation?.products[0]?.name ?? 'sản phẩm Simple phù hợp'

  return `Khách có xu hướng ${skinType}, concern chính là ${primaryConcern}. Nên tư vấn routine Simple theo hướng ${goal}, ưu tiên ${firstProduct}.`
}

function Section({
  title,
  children,
}: {
  title: string
  children: ReactNode
}) {
  return (
    <section className="rounded-lg border border-line bg-white p-3.5">
      <h2 className="mb-2 text-[10px] font-medium uppercase tracking-widest text-tertiary">
        {title}
      </h2>
      {children}
    </section>
  )
}

export default function BAHandoffView({
  skinResult,
  recommendation,
  promo = mockWatsonPromo,
  onBack,
}: BAHandoffViewProps) {
  if (!skinResult) {
    return (
      <div className="flex flex-col">
        <p className="mb-4 text-[11px] text-tertiary">
          Chưa có kết quả scan để tóm tắt cho BA.
        </p>
        {onBack ? (
          <button
            type="button"
            className="h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
            onClick={onBack}
          >
            Quay lại kết quả
          </button>
        ) : null}
      </div>
    )
  }

  const baPitch = buildBaPitch(skinResult, recommendation)
  const concernLabels = formatConcernList(skinResult.concerns)

  return (
    <div className="flex flex-col">
      <header className="mb-3.5">
        <h1 className="font-serif text-lg text-ink">Gợi ý cho BA</h1>
        <p className="mt-1 text-[11px] leading-snug text-muted">
          Tóm tắt nhanh để BA tư vấn tại quầy — dựa trên kết quả scan.
        </p>
      </header>

      <div className="flex flex-col gap-3">
        <Section title="Skin profile">
          <p className="mb-1.5 font-serif text-sm text-ink">
            {formatSkinType(skinResult.skinType)}
          </p>
          {skinResult.insight ? (
            <p className="text-[11px] leading-snug text-muted">{skinResult.insight}</p>
          ) : null}
        </Section>

        <Section title="Concern chính">
          {skinResult.concerns.length ? (
            <p className="text-sm text-ink">{concernLabels}</p>
          ) : (
            <p className="text-[11px] text-tertiary">Chưa có concern nổi bật.</p>
          )}
        </Section>

        <Section title="Routine Simple gợi ý">
          {recommendation ? (
            <>
              <p className="mb-2 font-serif text-sm text-ink">{recommendation.title}</p>
              <p className="mb-2.5 text-[11px] leading-snug text-muted">
                {recommendation.summary}
              </p>
              <ul className="flex flex-col gap-1.5">
                {recommendation.products.map((product) => (
                  <li
                    key={product.id}
                    className="text-[11px] text-ink before:mr-1.5 before:text-muted before:content-['•']"
                  >
                    {product.name}
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p className="text-[11px] text-tertiary">Chưa có gợi ý routine.</p>
          )}
        </Section>

        <Section title="Câu tư vấn nhanh">
          <p className="rounded-md bg-unilever-50 px-3 py-2.5 text-[11px] leading-relaxed text-unilever-900">
            {baPitch}
          </p>
        </Section>

        <Section title="Promo / combo cần kiểm tra">
          <p className="mb-1 font-serif text-sm text-ink">{promo.comboName}</p>
          <p className="mb-1 text-[11px] leading-snug text-muted">{promo.description}</p>
          <p className="text-[10px] leading-snug text-tertiary">{promo.disclaimer}</p>
        </Section>
      </div>

      {onBack ? (
        <button
          type="button"
          className="mt-4 h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
          onClick={onBack}
        >
          Quay lại kết quả
        </button>
      ) : null}
    </div>
  )
}
