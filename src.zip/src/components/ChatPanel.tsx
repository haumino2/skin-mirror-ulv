import { useState } from 'react'
import { Mic, Send } from 'lucide-react'
import { answerVietnameseQuestion } from '../lib/chatEngine'
import { trackEvent } from '../lib/eventTracker'
import {
  isSpeechRecognitionSupported,
  startVietnameseSpeechRecognition,
} from '../lib/speechRecognition'
import type {
  ChatMessage,
  RoutinePreference,
  RoutineRecommendation,
  SkinAnalysisResult,
  SkinGoal,
} from '../types/skinMirror'

export type ChatPanelProps = {
  skinResult?: SkinAnalysisResult
  recommendation?: RoutineRecommendation
  selectedGoal?: SkinGoal
  selectedPreference?: RoutinePreference
  onMessageSent?: (question: string) => void
}

const SUGGESTED_QUESTIONS = [
  'Da dầu dùng kem dưỡng này được không?',
  'Nếu chỉ mua 1 sản phẩm thì nên chọn gì?',
  'Routine này dùng sáng hay tối?',
  'Da nhạy cảm cần lưu ý gì?',
  'Có combo nào hợp hơn không?',
] as const

function createMessage(role: ChatMessage['role'], content: string): ChatMessage {
  return {
    role,
    content,
    timestamp: new Date().toISOString(),
  }
}

export default function ChatPanel({
  skinResult,
  recommendation,
  selectedGoal,
  selectedPreference,
  onMessageSent,
}: ChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null)

  const handleVoiceInput = async () => {
    setVoiceNotice(null)

    if (!skinResult) {
      setVoiceNotice('Chưa có kết quả scan — hãy hoàn tất scan trước khi hỏi.')
      return
    }

    if (!isSpeechRecognitionSupported()) {
      setVoiceNotice(
        'Trình duyệt này chưa hỗ trợ nhận giọng nói ổn định. Bạn có thể nhập câu hỏi bằng bàn phím.',
      )
      return
    }

    if (isListening) return

    setIsListening(true)
    try {
      const transcript = await startVietnameseSpeechRecognition()
      setInput(transcript)
    } catch {
      // User can retry or type manually
    } finally {
      setIsListening(false)
    }
  }

  const submitQuestion = (question: string) => {
    const trimmed = question.trim()
    if (!trimmed) return

    if (!skinResult) {
      setMessages((prev) => [
        ...prev,
        createMessage('user', trimmed),
        createMessage(
          'assistant',
          'Chưa có kết quả scan — hãy hoàn tất scan trước khi hỏi về routine.',
        ),
      ])
      setInput('')
      return
    }

    const answer = answerVietnameseQuestion({
      question: trimmed,
      skinResult,
      recommendation,
      selectedGoal,
      selectedPreference,
    })

    setMessages((prev) => [
      ...prev,
      createMessage('user', trimmed),
      createMessage('assistant', answer),
    ])
    setInput('')
    trackEvent('chat_question_sent', { questionLength: trimmed.length })
    onMessageSent?.(trimmed)
  }

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    submitQuestion(input)
  }

  return (
    <section className="flex flex-col gap-3 rounded-lg border border-line bg-white p-4">
      <header>
        <h2 className="font-serif text-base text-ink">Hỏi Skin Mirror AI</h2>
        <p className="mt-0.5 text-[11px] leading-snug text-tertiary">
          Gợi ý dựa trên kết quả scan — không thay tư vấn chuyên môn.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        {SUGGESTED_QUESTIONS.map((chip) => (
          <button
            key={chip}
            type="button"
            onClick={() => submitQuestion(chip)}
            className="rounded-md border border-line bg-cream px-3 py-2 text-left text-[11px] leading-snug text-ink hover:border-unilever-400 hover:bg-unilever-50/30 min-h-[2.75rem]"
          >
            {chip}
          </button>
        ))}
      </div>

      {messages.length > 0 && (
        <div className="flex max-h-52 flex-col gap-2.5 overflow-y-auto rounded-md bg-sand/60 p-3">
          {messages.map((message, index) => (
            <div
              key={`${message.timestamp}-${index}`}
              className={[
                'rounded-md px-3 py-2 text-[12px] leading-relaxed',
                message.role === 'user'
                  ? 'ml-6 bg-unilever-50 text-ink'
                  : 'mr-4 border border-line bg-white text-ink',
              ].join(' ')}
            >
              <span className="mb-0.5 block text-[9px] font-medium uppercase tracking-wide text-tertiary">
                {message.role === 'user' ? 'Bạn' : 'Skin Mirror'}
              </span>
              {message.content}
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-col gap-2">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Nhập câu hỏi về routine hoặc sản phẩm..."
            className="h-11 min-w-0 flex-1 rounded-md border border-line bg-white px-3 text-sm text-ink placeholder:text-tertiary focus:border-unilever-600 focus:outline-none"
            aria-label="Câu hỏi cho Skin Mirror AI"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-ink text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label="Gửi câu hỏi"
          >
            <Send className="h-4 w-4" aria-hidden />
          </button>
        </form>

        <button
          type="button"
          onClick={handleVoiceInput}
          disabled={isListening}
          className="flex h-11 items-center justify-center gap-2 rounded-md border border-line bg-cream px-3 text-sm text-ink hover:border-unilever-400 hover:bg-unilever-50/30 disabled:cursor-not-allowed disabled:opacity-60"
          aria-label="Hỏi bằng giọng nói"
        >
          <Mic className="h-4 w-4 shrink-0" aria-hidden />
          Hỏi bằng giọng nói
        </button>

        {isListening && (
          <p className="text-[11px] text-muted" role="status" aria-live="polite">
            Đang nghe...
          </p>
        )}

        {voiceNotice && (
          <p className="text-[11px] leading-snug text-muted" role="status">
            {voiceNotice}
          </p>
        )}
      </div>
    </section>
  )
}
