import { trackEvent } from '../lib/eventTracker'
import type { Product, RoutineRecommendation as RoutineRecommendationData } from '../types/skinMirror'

export type RoutineRecommendationProps = {
  recommendation?: RoutineRecommendationData
  onProductClick?: (productId: string) => void
  onShowBA?: () => void
}

const ROUTINE_STEP_ORDER: Product['routineStep'][] = [
  'cleanse',
  'hydrate',
  'calm_repair',
  'protect',
]

const STEP_LABELS: Record<Product['routineStep'], string> = {
  cleanse: 'Làm sạch',
  hydrate: 'Cấp ẩm',
  calm_repair: 'Làm dịu & phục hồi',
  protect: 'Bảo vệ',
}

function stepOrderIndex(step: Product['routineStep']): number {
  const index = ROUTINE_STEP_ORDER.indexOf(step)
  return index === -1 ? ROUTINE_STEP_ORDER.length : index
}

function sortProductsByRoutineStep(products: Product[]): Product[] {
  return [...products].sort(
    (a, b) => stepOrderIndex(a.routineStep) - stepOrderIndex(b.routineStep),
  )
}

function ProductRoutineCard({
  product,
  onProductClick,
  onShowBA,
}: {
  product: Product
  onProductClick?: (productId: string) => void
  onShowBA?: () => void
}) {
  const stepLabel = STEP_LABELS[product.routineStep]

  return (
    <article className="relative rounded-lg border border-line bg-white p-3.5 min-w-0">
      <span className="absolute left-3 top-[-7px] rounded-sm bg-unilever-600 px-1.5 py-0.5 text-[9px] font-medium tracking-wide text-white">
        {stepLabel}
      </span>

      <div className="mb-1 font-serif text-sm leading-tight text-ink break-words">
        {product.name}
      </div>

      <p className="mb-2 text-[11px] leading-snug text-muted break-words">
        {product.whyRecommended}
      </p>

      <p className="mb-2.5 text-[10px] leading-snug text-tertiary break-words">
        <span className="font-medium text-ink">Cách dùng: </span>
        {product.usage}
      </p>

      {product.claims.length > 0 ? (
        <div className="mb-3 flex flex-wrap gap-1.5">
          {product.claims.map((claim) => (
            <span
              key={claim}
              className="rounded-sm bg-unilever-50 px-2 py-0.5 text-[10px] font-medium text-unilever-600"
            >
              {claim}
            </span>
          ))}
        </div>
      ) : null}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <button
          type="button"
          className="h-11 flex-1 rounded-md bg-unilever-600 text-sm font-medium text-white hover:opacity-90"
          onClick={() => {
            trackEvent('product_card_clicked', { productId: product.id })
            onProductClick?.(product.id)
          }}
        >
          Thêm vào routine
        </button>

        {onShowBA ? (
          <button
            type="button"
            className="h-11 shrink-0 rounded-md border border-line bg-white px-4 text-sm text-ink hover:bg-sand sm:min-w-[7.5rem]"
            onClick={onShowBA}
          >
            Show to BA
          </button>
        ) : null}
      </div>
    </article>
  )
}

export default function RoutineRecommendation({
  recommendation,
  onProductClick,
  onShowBA,
}: RoutineRecommendationProps) {
  if (!recommendation) {
    return (
      <p className="rounded-lg border border-line bg-white px-3.5 py-3 text-[11px] text-tertiary">
        Chưa có gợi ý routine Simple. Hãy scan lại để nhận gợi ý phù hợp.
      </p>
    )
  }

  const simpleProducts = sortProductsByRoutineStep(
    recommendation.products.filter((product) => product.brand === 'Simple'),
  )

  return (
    <section className="flex flex-col">
      <header className="mb-3">
        <h2 className="mb-1 font-serif text-lg text-ink">
          Routine Simple gợi ý cho bạn
        </h2>
        <p className="text-[11px] leading-relaxed text-muted">
          {recommendation.summary}
        </p>
      </header>

      {simpleProducts.length > 0 ? (
        <div className="flex flex-col gap-3">
          {simpleProducts.map((product) => (
            <ProductRoutineCard
              key={product.id}
              product={product}
              onProductClick={onProductClick}
              onShowBA={onShowBA}
            />
          ))}
        </div>
      ) : (
        <p className="rounded-lg border border-line bg-white px-3.5 py-3 text-[11px] text-tertiary">
          Chưa có sản phẩm Simple phù hợp cho routine này.
        </p>
      )}
    </section>
  )
}
