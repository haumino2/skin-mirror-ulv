import { useMemo, useState } from 'react'
import { mockWatsonPromo } from '../data/promoConfig'
import type { WatsonPromo } from '../data/promoConfig'
import { demoSessions } from '../data/demoSessions'
import { getConcernLabel } from '../data/vietnameseSkinGlossary'
import type { SkinAnalysisResult } from '../lib/claudeSkinAnalysis'
import { trackEvent } from '../lib/eventTracker'
import {
  buildRoutineRecommendation,
  getDefaultGoalFromSkinResult,
  getDefaultPreference,
} from '../lib/routineRecommendation'
import type {
  RoutinePreference,
  RoutineRecommendation,
  SkinGoal,
} from '../types/skinMirror'

type ShareAnalysisInput = SkinAnalysisResult & { insight?: string }

export interface ShareScreenProps {
  onDone: () => void
  onOpenAdmin?: () => void
  analysis?: ShareAnalysisInput | null
  routineRecommendation?: RoutineRecommendation
  watsonPromo?: WatsonPromo
  goal?: SkinGoal
  preference?: RoutinePreference
}

const demoFallback = demoSessions[0].result

const FALLBACK_ANALYSIS: ShareAnalysisInput = {
  skinType: 'combination',
  concerns: demoFallback.concerns,
  scores: {
    redness: demoFallback.scores.redness,
    oiliness: demoFallback.scores.oiliness,
    texture: demoFallback.scores.texture,
    pores: demoFallback.scores.pores,
    hydration: demoFallback.scores.hydration,
    pigmentation: demoFallback.scores.dullness,
  },
  recommendations: [],
  insight: demoFallback.insight,
}

const SKIN_TYPE_LABELS: Record<string, string> = {
  oily: 'Da dầu',
  dry: 'Da khô',
  combination: 'Da hỗn hợp',
  normal: 'Da thường',
}

function formatSkinTypeLabel(skinType: string): string {
  return SKIN_TYPE_LABELS[skinType] ?? skinType
}

/** Static 11×11 module pattern — CSS grid mock, not a scannable QR. */
const QR_MODULE_PATTERN =
  '11111110010' +
  '10000010010' +
  '10111010010' +
  '10111011111' +
  '10111010000' +
  '11111110101' +
  '00000010101' +
  '10101110111' +
  '10001010001' +
  '10001011101' +
  '11111110001'

function QrCodeMock() {
  return (
    <div
      className="grid h-[66px] w-[66px] shrink-0 grid-cols-11 grid-rows-11 gap-px border border-ink bg-line p-1"
      aria-hidden
    >
      {QR_MODULE_PATTERN.split('').map((cell, index) => (
        <div
          key={index}
          className={cell === '1' ? 'bg-ink' : 'bg-white'}
        />
      ))}
    </div>
  )
}

type MockAction = 'zalo' | 'watson' | 'screenshot' | null

export default function ShareScreen({
  onDone,
  onOpenAdmin,
  analysis,
  routineRecommendation,
  watsonPromo = mockWatsonPromo,
  goal,
  preference,
}: ShareScreenProps) {
  const [mockAction, setMockAction] = useState<MockAction>(null)

  const resolvedAnalysis = analysis ?? FALLBACK_ANALYSIS

  const resolvedRoutine = useMemo(() => {
    if (routineRecommendation) return routineRecommendation
    const resolvedGoal = goal ?? getDefaultGoalFromSkinResult(resolvedAnalysis)
    const resolvedPreference = preference ?? getDefaultPreference()
    return buildRoutineRecommendation(resolvedAnalysis, resolvedGoal, resolvedPreference)
  }, [routineRecommendation, goal, preference, resolvedAnalysis])

  const skinTypeLabel = formatSkinTypeLabel(resolvedAnalysis.skinType)
  const topConcerns = resolvedAnalysis.concerns.slice(0, 3)

  const savedDate = useMemo(
    () =>
      new Date().toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }),
    [],
  )

  const handleMockAction = (action: Exclude<MockAction, null>) => {
    setMockAction(action)
    if (action === 'zalo') {
      trackEvent('zalo_qr_clicked')
    } else {
      trackEvent('save_clicked', { action })
    }
    console.log(`[ShareScreen] mock action: ${action}`)
  }

  const mockFeedback =
    mockAction === 'zalo'
      ? 'Routine đã sẵn sàng lưu qua Zalo (demo).'
      : mockAction === 'watson'
        ? 'Ưu đãi Watson đã ghi nhận — hỏi BA tại quầy (demo).'
        : mockAction === 'screenshot'
          ? 'Bạn có thể chụp màn hình để lưu kết quả.'
          : null

  return (
    <div className="flex min-h-0 flex-1 flex-col px-4 py-4 text-center">
      <h2 className="mb-1 font-serif text-lg text-ink">Lưu routine của bạn</h2>
      <p className="mb-4 text-center text-[11px] leading-relaxed text-tertiary">
        Lưu routine, nhận ưu đãi Watson — chỉ khi bạn chủ động đồng ý
      </p>

      <div className="relative mx-auto mb-3 max-w-[300px] rounded-xl border border-line bg-white p-4 text-left">
        <p className="mb-3 font-serif text-[10px] uppercase tracking-widest text-tertiary">
          Simple Skin Mirror · Watson HCMC
        </p>

        <div className="mb-2.5">
          <p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-tertiary">
            Hồ sơ da
          </p>
          <p className="font-serif text-base leading-snug text-ink">{skinTypeLabel}</p>
          {resolvedAnalysis.insight ? (
            <p className="mt-1 text-[11px] leading-relaxed text-muted">
              {resolvedAnalysis.insight}
            </p>
          ) : null}
        </div>

        <div className="mb-3">
          <p className="mb-1.5 text-[10px] font-medium uppercase tracking-wide text-tertiary">
            Mối quan tâm chính
          </p>
          <div className="flex flex-wrap gap-1.5">
            {topConcerns.map((concern) => (
              <span
                key={concern}
                className="rounded-sm bg-unilever-50 px-2 py-0.5 text-[10px] font-medium text-unilever-600"
              >
                {getConcernLabel(concern)}
              </span>
            ))}
          </div>
        </div>

        <div className="mb-2 text-[11px] leading-relaxed text-muted">
          <span className="mb-1 block font-medium text-ink">
            {resolvedRoutine.title}
          </span>
          <span className="mb-1.5 block text-[10px] text-tertiary">
            {resolvedRoutine.summary}
          </span>
          {resolvedRoutine.products.map((product) => (
            <span key={product.id} className="block">
              {product.name}
            </span>
          ))}
        </div>

        <div className="mb-2 rounded-md border border-unilever-100 bg-unilever-50 px-2.5 py-2">
          <p className="mb-0.5 text-[10px] font-medium uppercase tracking-wide text-unilever-800">
            {watsonPromo.title}
          </p>
          <p className="text-[11px] font-medium text-ink">{watsonPromo.comboName}</p>
          <p className="mt-0.5 text-[10px] leading-relaxed text-muted">
            {watsonPromo.description}
          </p>
        </div>

        <p className="mt-2 border-t border-line pt-2 text-center text-[9px] italic text-tertiary">
          Kết quả phân tích bởi AI · {savedDate}
        </p>
      </div>

      <div className="mx-auto mb-3 flex max-w-[300px] items-center gap-3 rounded-md border border-line bg-white p-3">
        <QrCodeMock />
        <div className="min-w-0 flex-1 text-left">
          <p className="mb-0.5 text-xs font-medium text-ink">Quét để lưu routine</p>
          <p className="text-[10px] leading-relaxed text-tertiary">
            Mở Zalo hoặc camera — không cần app riêng
          </p>
        </div>
      </div>

      <div className="mx-auto mb-3 flex w-full max-w-[300px] flex-col gap-2">
        <button
          type="button"
          onClick={() => handleMockAction('zalo')}
          className="h-11 w-full rounded-md bg-unilever-600 text-sm font-medium text-white hover:opacity-90"
        >
          Lưu routine qua Zalo
        </button>
        <button
          type="button"
          onClick={() => handleMockAction('watson')}
          className="h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
        >
          Nhận ưu đãi tại Watson
        </button>
        <button
          type="button"
          onClick={() => handleMockAction('screenshot')}
          className="h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
        >
          Chụp màn hình kết quả
        </button>
      </div>

      {mockFeedback ? (
        <p className="mx-auto mb-2 max-w-[300px] text-[10px] leading-relaxed text-muted">
          {mockFeedback}
        </p>
      ) : null}

      <p className="mx-auto mb-3 max-w-[300px] text-[9px] leading-relaxed text-tertiary">
        Chỉ lưu thông tin khi bạn chủ động đồng ý. Ảnh gốc không được lưu mặc định.
      </p>

      <div className="mt-auto pt-2">
        <button
          type="button"
          onClick={onDone}
          className="h-11 w-full rounded-md bg-ink text-sm font-medium text-white hover:opacity-90"
        >
          Xong, ra quầy
        </button>
        {onOpenAdmin ? (
          <button
            type="button"
            onClick={onOpenAdmin}
            className="mt-3 w-full py-2 text-[10px] text-tertiary underline-offset-2 hover:text-muted hover:underline"
          >
            Mở dashboard demo
          </button>
        ) : null}
      </div>
    </div>
  )
}
