import { useMemo, useState } from "react"
import { ChevronDown } from "lucide-react"
import SkinMapDetail from "./SkinMapDetail"
import RoutineRecommendation from "./RoutineRecommendation"
import BAHandoffView from "./BAHandoffView"
import PromoHandoff from "./PromoHandoff"
import ChatPanel from "./ChatPanel"
import AudioAdviceButton from "./AudioAdviceButton"
import { audioScripts, type AudioScriptId } from "../data/audioScripts"
import { mockWatsonPromo } from "../data/promoConfig"
import { normalizeAnalysisToSkinResult } from "../lib/demoFallback"
import type { SkinAnalysisResult, SkinScores, SkinType } from "../lib/claudeSkinAnalysis"
import type {
  RoutinePreference,
  RoutineRecommendation as RoutineRecommendationData,
  SkinAnalysisResult as DemoSkinResult,
  SkinGoal,
} from "../types/skinMirror"

function isAudioScriptId(id: string): id is AudioScriptId {
  return id in audioScripts
}

function buildFallbackAudioScript(
  skinResult: DemoSkinResult,
  recommendation?: RoutineRecommendationData,
): string {
  const insight = skinResult.insight.trim()
  const routineSummary =
    recommendation?.summary.trim() ||
    "Skin Mirror gợi ý routine Simple tối giản phù hợp với kết quả scan."
  const closing =
    "Bạn có thể lưu routine này hoặc hỏi BA để kiểm tra combo phù hợp hôm nay."

  if (insight) {
    return `${insight} ${routineSummary} ${closing}`
  }

  const skinType = skinResult.skinType.trim() || "da hiện tại"
  return `Theo kết quả scan, da bạn là ${skinType}. ${routineSummary} ${closing}`
}

export interface ResultScreenProps {
  analysis: SkinAnalysisResult | null
  routineRecommendation?: RoutineRecommendationData
  selectedGoal?: SkinGoal
  selectedPreference?: RoutinePreference
  onNext: () => void
  onScanAgain: () => void
  onFeedbackNo: () => void
  onSaveOffer?: () => void
  onShowBA?: () => void
  onAskBA?: () => void
  audioScriptId?: string
  onAudioPlayed?: () => void
}

export default function ResultScreen({
  analysis,
  routineRecommendation,
  selectedGoal,
  selectedPreference,
  onNext,
  onScanAgain,
  onFeedbackNo,
  onSaveOffer,
  onShowBA,
  onAskBA,
  audioScriptId,
  onAudioPlayed,
}: ResultScreenProps) {
  const [showDetails, setShowDetails] = useState<boolean>(false)
  const [chatExpanded, setChatExpanded] = useState(false)
  const [showBAHandoff, setShowBAHandoff] = useState(false)

  const chatSkinResult = useMemo(() => {
    if (!analysis) return null
    return normalizeAnalysisToSkinResult({
      skinType: analysis.skinType,
      concerns: analysis.concerns,
      scores: {
        hydration: analysis.scores.hydration,
        oiliness: analysis.scores.oiliness,
        redness: analysis.scores.redness,
        texture: analysis.scores.texture,
        pores: analysis.scores.pores,
        dullness: analysis.scores.pigmentation,
      },
      insight: analysis.recommendations[0],
      confidenceLabel: "ai_generated",
    })
  }, [analysis])

  const audioAdvice = useMemo(() => {
    if (!chatSkinResult) return null

    if (audioScriptId && isAudioScriptId(audioScriptId)) {
      const script = audioScripts[audioScriptId]
      return { text: script.text, audioUrl: script.audioUrl }
    }

    return {
      text: buildFallbackAudioScript(chatSkinResult, routineRecommendation),
      audioUrl: undefined,
    }
  }, [audioScriptId, chatSkinResult, routineRecommendation])

  const skinTypeLabel = useMemo(() => {
    const t: SkinType | undefined = analysis?.skinType
    switch (t) {
      case "oily":
        return "Da dầu"
      case "dry":
        return "Da khô"
      case "combination":
        return "Da hỗn hợp"
      case "normal":
      default:
        return "Da thường"
    }
  }, [analysis?.skinType])

  const concerns = analysis?.concerns ?? []
  const scores = analysis?.scores

  const scoreRows: Array<{ key: keyof SkinScores; label: string }> = [
    { key: "redness", label: "Đỏ/viêm" },
    { key: "oiliness", label: "Dầu" },
    { key: "texture", label: "Texture" },
    { key: "pores", label: "Lỗ chân lông" },
    { key: "hydration", label: "Thiếu ẩm" },
    { key: "pigmentation", label: "Sạm/nám" },
  ]

  const barColor = (v: number) => {
    if (v <= 33) return "bg-green-500"
    if (v <= 66) return "bg-yellow-500"
    return "bg-red-500"
  }

  const handleSaveOffer = () => {
    if (onSaveOffer) {
      onSaveOffer()
      return
    }
    console.log("[PromoHandoff] onSaveOffer — save/share step not wired")
  }

  const handleShowBA = () => {
    if (onShowBA) {
      onShowBA()
      return
    }
    setShowBAHandoff(true)
  }

  const handleAskBA = () => {
    setChatExpanded(true)
    onAskBA?.()
  }

  if (showBAHandoff && chatSkinResult) {
    return (
      <BAHandoffView
        skinResult={chatSkinResult}
        recommendation={routineRecommendation}
        promo={mockWatsonPromo}
        onBack={() => setShowBAHandoff(false)}
      />
    )
  }

  return (
    <div className="flex flex-col">
      <div className="flex justify-between items-start mb-2">
        <div className="min-w-0">
          <div className="font-serif text-lg text-ink mb-0.5">Da của bạn</div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center rounded-full bg-unilever-50 border border-unilever-100 px-2.5 py-1 text-[11px] font-medium text-unilever-900">
              {skinTypeLabel}
            </span>

            {concerns.slice(0, 2).map((c) => (
              <span
                key={c}
                className="inline-flex items-center rounded-full bg-white border border-line px-2.5 py-1 text-[11px] text-tertiary"
              >
                {c}
              </span>
            ))}
          </div>
        </div>

        <button
          type="button"
          className="bg-transparent border border-tertiary text-ink text-[11px] px-2.5 py-1 rounded-md shrink-0"
          onClick={onScanAgain}
        >
          Scan lại
        </button>
      </div>

      <div className="mb-3.5 bg-unilever-50 rounded-lg border-l-[3px] border-l-unilever-600 px-4 py-3">
        <div className="text-[10px] text-unilever-600 uppercase tracking-widest font-medium mb-1">
          INSIGHT CHÍNH
        </div>
        <div className="font-serif text-sm text-unilever-900 leading-snug">
          {analysis
            ? "Tổng quan: xem các scores & concerns bên dưới để tối ưu routine."
            : "Chưa có dữ liệu phân tích. Hãy scan lại để nhận kết quả."}
        </div>

        {audioAdvice ? (
          <div className="mt-3 pt-3 border-t border-unilever-100">
            <p className="mb-2 text-[10px] leading-snug text-muted">
              Tùy chọn nghe tư vấn bằng tiếng Việt.
            </p>
            <AudioAdviceButton
              script={audioAdvice.text}
              audioUrl={audioAdvice.audioUrl}
              label="Nghe tư vấn"
              onPlayed={onAudioPlayed}
              compact
            />
          </div>
        ) : null}
      </div>

      {scores ? (
        <div className="mb-3.5 bg-white border border-line rounded-lg px-3.5 py-3">
          <div className="text-[10px] text-tertiary uppercase tracking-widest font-medium mb-2">
            Scores (0–100)
          </div>
          <div className="flex flex-col gap-2.5">
            {scoreRows.map((row) => {
              const v = scores[row.key]
              return (
                <div key={row.key} className="flex items-center gap-2">
                  <div className="text-[11px] text-muted min-w-[86px]">{row.label}</div>
                  <div className="flex-1 h-2 bg-line rounded-full overflow-hidden">
                    <div
                      className={["h-full rounded-full", barColor(v)].join(" ")}
                      style={{ width: `${v}%` }}
                    />
                  </div>
                  <div className="text-[11px] font-medium text-ink min-w-[28px] text-right">
                    {v}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ) : null}

      {concerns.length ? (
        <div className="mb-3">
          <div className="text-[10px] text-tertiary uppercase tracking-widest font-medium mb-2">
            Concerns
          </div>
          <div className="flex flex-wrap gap-1.5">
            {concerns.map((c) => (
              <span
                key={c}
                className="inline-flex items-center rounded-full bg-white border border-line px-2.5 py-1 text-[11px] text-ink"
              >
                {c}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mb-3.5">
        {routineRecommendation ? (
          <RoutineRecommendation recommendation={routineRecommendation} />
        ) : (
          <p className="rounded-lg border border-line bg-white px-3.5 py-3 text-[11px] text-tertiary">
            Chưa có gợi ý routine. Hãy scan lại để nhận gợi ý Simple phù hợp.
          </p>
        )}
      </div>

      <div className="mb-3.5">
        <PromoHandoff
          promo={mockWatsonPromo}
          onSaveOffer={handleSaveOffer}
          onShowBA={handleShowBA}
          onAskBA={handleAskBA}
        />
      </div>

      {chatSkinResult ? (
        <div className="mb-3.5">
          <button
            type="button"
            className="flex w-full items-center justify-between gap-2 rounded-lg border border-line bg-white px-3.5 py-2.5 text-left"
            onClick={() => setChatExpanded((open) => !open)}
            aria-expanded={chatExpanded}
          >
            <span className="min-w-0">
              <span className="block font-serif text-sm text-ink">Hỏi thêm về routine</span>
              <span className="mt-0.5 block text-[10px] leading-snug text-tertiary">
                Gợi ý ngắn dựa trên kết quả scan — không thay tư vấn chuyên môn
              </span>
            </span>
            <ChevronDown
              className={[
                "h-4 w-4 shrink-0 text-muted transition-transform",
                chatExpanded ? "rotate-180" : "",
              ].join(" ")}
              aria-hidden
            />
          </button>

          {chatExpanded ? (
            <div className="mt-2">
              <ChatPanel
                skinResult={chatSkinResult}
                recommendation={routineRecommendation}
                selectedGoal={selectedGoal}
                selectedPreference={selectedPreference}
              />
            </div>
          ) : null}
        </div>
      ) : null}

      <button
        type="button"
        className="mt-3 mb-3 w-full text-[11px] text-unilever-600 bg-transparent border border-dashed border-unilever-100 rounded-md py-2 px-3 cursor-pointer"
        onClick={() => setShowDetails((v) => !v)}
      >
        {showDetails ? "Ẩn chi tiết phân tích" : "Xem chi tiết phân tích da"}
      </button>

      {showDetails ? (
        <div className="mt-3 pt-3.5 border-t border-line transition-opacity duration-200 opacity-100">
          <SkinMapDetail />
        </div>
      ) : null}

      <div className="mt-3.5 bg-white border border-line rounded-lg px-3 py-2.5 flex justify-between items-center gap-2">
        <div className="text-[11px] text-muted flex-1">
          Gợi ý này có phù hợp với bạn?
        </div>
        <div className="flex gap-1.5 shrink-0">
          <button
            type="button"
            className="text-[11px] px-2.5 py-1 bg-transparent border border-green-200 text-green-700 rounded-md hover:bg-green-50"
            onClick={onNext}
          >
            Có
          </button>
          <button
            type="button"
            className="text-[11px] px-2.5 py-1 bg-transparent border border-red-200 text-red-700 rounded-md hover:bg-red-50"
            onClick={onFeedbackNo}
          >
            Không phù hợp
          </button>
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <button
          type="button"
          className="flex-1 bg-ink text-white text-sm font-medium py-2.5 rounded-md hover:opacity-90"
          onClick={onNext}
        >
          Lấy ra quầy
        </button>
      </div>
    </div>
  )
}

