import { mockWatsonPromo, type WatsonPromo } from '../data/promoConfig'
import { trackEvent } from '../lib/eventTracker'

export type PromoHandoffProps = {
  promo?: WatsonPromo
  onSaveOffer: () => void
  onShowBA: () => void
  onAskBA: () => void
}

export default function PromoHandoff({
  promo = mockWatsonPromo,
  onSaveOffer,
  onShowBA,
  onAskBA,
}: PromoHandoffProps) {
  return (
    <section className="rounded-lg border border-line bg-white p-3.5">
      <header className="mb-3">
        <h2 className="mb-1 font-serif text-base leading-snug text-ink">
          {promo.title}
        </h2>
        <p className="mb-1.5 text-sm font-medium text-ink">{promo.comboName}</p>
        <p className="text-[11px] leading-relaxed text-muted">
          {promo.description}
        </p>
      </header>

      <div className="flex flex-col gap-2">
        <button
          type="button"
          className="h-11 w-full rounded-md bg-unilever-600 text-sm font-medium text-white hover:opacity-90"
          onClick={() => {
            trackEvent('promo_clicked', { comboName: promo.comboName })
            onSaveOffer()
          }}
        >
          {promo.ctaPrimary}
        </button>

        <button
          type="button"
          className="h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
          onClick={() => {
            trackEvent('ba_handoff_clicked')
            onShowBA()
          }}
        >
          {promo.ctaSecondary}
        </button>

        <button
          type="button"
          className="h-11 w-full rounded-md border border-line bg-white text-sm text-ink hover:bg-sand"
          onClick={onAskBA}
        >
          {promo.ctaTertiary}
        </button>
      </div>

      <p className="mt-3 text-[9px] leading-relaxed text-tertiary">
        {promo.disclaimer}
      </p>
    </section>
  )
}
