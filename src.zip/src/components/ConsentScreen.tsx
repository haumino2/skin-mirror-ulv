import { trackEvent } from '../lib/eventTracker'

export interface ConsentScreenProps {
  onAccept: () => void
  onCancel: () => void
}

export default function ConsentScreen({ onAccept, onCancel }: ConsentScreenProps) {
  const handleAccept = () => {
    trackEvent('consent_accepted')
    onAccept()
  }
  return (
    <div className="flex flex-col h-full">
      <div className="font-serif text-xl text-ink mb-4">Trước khi scan da</div>

      <div className="bg-white border border-line rounded-md p-3.5 mb-4">
        <div className="space-y-1">
          <div className="text-xs text-muted leading-relaxed">
            · Ảnh chỉ được dùng để phân tích da trong phiên này.
          </div>
          <div className="text-xs text-muted leading-relaxed">
            · Skin Mirror không lưu ảnh gốc nếu bạn không đồng ý.
          </div>
          <div className="text-xs text-muted leading-relaxed">
            · Kết quả chỉ mang tính tham khảo chăm sóc da, không thay thế tư vấn chuyên môn.
          </div>
        </div>
      </div>

      <div className="flex gap-2.5">
        <button
          type="button"
          className="h-11 bg-ink text-white px-4 py-2.5 rounded-md text-sm font-medium hover:opacity-90 flex-shrink-0 flex items-center justify-center"
          onClick={handleAccept}
        >
          Tôi đồng ý và bắt đầu
        </button>
        <button
          type="button"
          className="h-11 bg-transparent border border-tertiary text-ink px-4 py-2.5 rounded-md text-sm hover:bg-sand flex items-center justify-center"
          onClick={onCancel}
        >
          Quay lại
        </button>
      </div>
    </div>
  )
}
