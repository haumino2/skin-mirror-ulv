export interface IdleScreenProps {
  onStart: () => void
}

export default function IdleScreen({ onStart }: IdleScreenProps) {
  return (
    <div className="h-full min-h-full flex flex-col items-center justify-center text-center gap-4 px-4">
      <div className="w-15 h-15 rounded-full bg-unilever-600 opacity-15 animate-pulse mb-2" />

      <div className="text-xs text-tertiary tracking-wide">
        Simple Skin Mirror · Watson HCMC
      </div>

      <div>
        <div className="font-serif text-xl text-ink mb-1.5">Scan da trong 30 giây</div>
        <div className="text-xs text-muted leading-relaxed max-w-[280px] mx-auto">
          Kiểm tra nhanh để xem da bạn hợp routine Simple nào trước khi mua.
        </div>
      </div>

      <div className="flex flex-col gap-2.5 w-full max-w-[280px] mt-2">
        <button
          type="button"
          className="h-11 bg-ink text-white px-5 rounded-md text-sm font-medium hover:opacity-90 transition flex items-center justify-center"
          onClick={onStart}
        >
          Bắt đầu scan
        </button>
        <button
          type="button"
          className="h-11 bg-transparent border border-tertiary text-ink px-5 rounded-md text-sm hover:bg-sand transition flex items-center justify-center"
        >
          Quét QR để scan trên điện thoại
        </button>
      </div>

      <p className="text-xs text-tertiary leading-relaxed max-w-[280px]">
        Không lưu ảnh gốc nếu bạn không đồng ý.
      </p>
    </div>
  )
}
