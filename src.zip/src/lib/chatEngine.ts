import { mockWatsonPromo } from '../data/promoConfig'
import { sanitizeBeautyCopy } from '../data/vietnamesePersona'
import { formatConcernList } from '../data/vietnameseSkinGlossary'
import type {
  Product,
  RoutinePreference,
  RoutineRecommendation,
  SkinAnalysisResult,
  SkinGoal,
} from '../types/skinMirror'

export type AnswerVietnameseQuestionParams = {
  question: string
  skinResult: SkinAnalysisResult
  recommendation?: RoutineRecommendation
  selectedGoal?: SkinGoal
  selectedPreference?: RoutinePreference
}

const SKIN_TYPE_LABELS: Record<string, string> = {
  oily: 'da dầu',
  dry: 'da khô',
  combination: 'da hỗn hợp',
  normal: 'da thường',
}

const GOAL_LABELS: Record<SkinGoal, string> = {
  hydrate: 'cấp ẩm',
  reduce_oil: 'giảm dầu',
  calm: 'làm dịu',
  smooth_texture: 'cải thiện texture',
}

const STEP_LABELS: Record<Product['routineStep'], string> = {
  cleanse: 'làm sạch',
  hydrate: 'cấp ẩm',
  calm_repair: 'làm dịu & phục hồi',
  protect: 'bảo vệ',
}

const ROUTINE_STEP_ORDER: Product['routineStep'][] = [
  'cleanse',
  'hydrate',
  'calm_repair',
  'protect',
]

function normalizeQuestion(question: string): string {
  return question.trim().toLowerCase()
}

function getSkinTypeLabel(skinType: string): string {
  return SKIN_TYPE_LABELS[skinType] ?? skinType
}

function sortProductsByStep(products: Product[]): Product[] {
  return [...products].sort(
    (a, b) =>
      ROUTINE_STEP_ORDER.indexOf(a.routineStep) - ROUTINE_STEP_ORDER.indexOf(b.routineStep),
  )
}

function findMoisturizer(recommendation?: RoutineRecommendation): Product | undefined {
  if (!recommendation) return undefined
  return recommendation.products.find(
    (p) => p.routineStep === 'hydrate' || p.routineStep === 'calm_repair',
  )
}

function findPrimarySingleProduct(
  recommendation: RoutineRecommendation | undefined,
  goal: SkinGoal | undefined,
): Product | undefined {
  if (!recommendation || recommendation.products.length === 0) return undefined

  const sorted = sortProductsByStep(recommendation.products)

  if (goal === 'calm') {
    return (
      sorted.find((p) => p.routineStep === 'calm_repair') ??
      sorted.find((p) => p.routineStep === 'hydrate') ??
      sorted[0]
    )
  }

  if (goal === 'reduce_oil') {
    return (
      sorted.find((p) => p.routineStep === 'hydrate') ??
      sorted.find((p) => p.routineStep === 'cleanse') ??
      sorted[0]
    )
  }

  return sorted.find((p) => p.routineStep !== 'cleanse') ?? sorted[0]
}

function hasSensitiveSignal(skinResult: SkinAnalysisResult): boolean {
  const concernText = skinResult.concerns.join(' ').toLowerCase()
  return (
    skinResult.concerns.includes('sensitivity') ||
    skinResult.concerns.includes('redness') ||
    concernText.includes('nhạy') ||
    skinResult.scores.redness >= 55
  )
}

function answerOilyMoisturizer(
  skinResult: SkinAnalysisResult,
  recommendation?: RoutineRecommendation,
): string {
  const moisturizer = findMoisturizer(recommendation)
  const productName = moisturizer?.name ?? 'kem dưỡng nhẹ Simple'
  const skinLabel = getSkinTypeLabel(skinResult.skinType)
  const oilScore = skinResult.scores.oiliness

  return [
    `Có, ${skinLabel} vẫn nên dùng ${productName} — bỏ qua bước dưỡng dễ khiến da bù dầu hơn.`,
    oilScore >= 55
      ? 'Kết quả scan cho thấy vùng chữ T dễ bóng, nên chọn kết cấu nhẹ, không bí da.'
      : 'Dưỡng ẩm nhẹ giúp cân bằng mà không làm da nặng mặt.',
    'Lấy lượng nhỏ, thoa đều và tập trung vùng má; vùng chữ T chỉ cần một lớp mỏng.',
  ].join(' ')
}

function answerSingleProduct(
  skinResult: SkinAnalysisResult,
  recommendation: RoutineRecommendation | undefined,
  goal: SkinGoal | undefined,
): string {
  const resolvedGoal = goal ?? recommendation?.goal ?? 'hydrate'
  const pick = findPrimarySingleProduct(recommendation, resolvedGoal)
  const productName = pick?.name ?? 'Simple Hydrating Light Moisturizer'
  const goalLabel = GOAL_LABELS[resolvedGoal]

  return [
    `Nếu chỉ mua một sản phẩm, nên ưu tiên ${productName}.`,
    `Với mục tiêu ${goalLabel} và ${getSkinTypeLabel(skinResult.skinType)}, đây là bước mang lại cảm giác khác biệt rõ nhất sau làm sạch.`,
    pick?.usage
      ? `${pick.usage} Nếu routine thiếu sữa rửa mặt, hãy rửa nhẹ bằng nước ấm trước khi thoa.`
      : 'Dùng sau khi làm sạch da, lấy lượng vừa đủ và thoa đều.',
  ].join(' ')
}

function answerRoutineTiming(
  recommendation: RoutineRecommendation | undefined,
): string {
  const productNames =
    recommendation?.products.map((p) => p.name).join(' và ') ?? 'routine Simple gợi ý'

  return [
    'Routine này dùng được cả sáng và tối — sáng giúp chuẩn bị da, tối hỗ trợ phục hồi sau một ngày.',
    `${productNames} đều phù hợp dùng hai buổi nếu da không bị kích ứng.`,
    'Buổi sáng: làm sạch → dưỡng; buổi tối: lặp lại và có thể thoa dưỡng dày hơn một chút ở vùng khô.',
  ].join(' ')
}

function answerSensitiveCaution(
  skinResult: SkinAnalysisResult,
  recommendation?: RoutineRecommendation,
): string {
  const concerns = formatConcernList(skinResult.concerns)
  const soothing = recommendation?.products.find((p) => p.routineStep === 'calm_repair')

  return [
    'Da nhạy cảm nên bắt đầu từng bước, mỗi sản phẩm mới khoảng 3–5 ngày và patch test sau tai trước.',
    concerns
      ? `Scan ghi nhận ${concerns} — ưu tiên công thức không hương liệu, không xà phòng như Simple.`
      : 'Ưu tiên công thức không hương liệu, không xà phòng như Simple.',
    soothing
      ? `Có thể cân nhắc ${soothing.name}; nếu da hơi châm chích, giảm tần suất hoặc hỏi BA tại quầy.`
      : 'Nếu da hơi châm chích, giảm tần suất dùng và hỏi BA tại quầy Watson.',
  ].join(' ')
}

function answerComboPromo(
  recommendation: RoutineRecommendation | undefined,
  preference: RoutinePreference | undefined,
): string {
  const comboName = mockWatsonPromo.comboName
  const productCount = recommendation?.products.length ?? 2

  return [
    preference === 'promo_combo'
      ? `Routine hiện đã theo hướng combo — ${comboName} thường gồm làm sạch + dưỡng phù hợp mua cùng lúc.`
      : `Có thể cân nhắc ${comboName} tại Watson nếu muốn mua trọn ${productCount} bước với ưu đãi.`,
    mockWatsonPromo.description,
    'Hỏi BA tại quầy Simple để kiểm tra combo đang chạy hôm nay — ưu đãi demo có thể khác theo cửa hàng.',
  ].join(' ')
}

function answerProductOrder(recommendation?: RoutineRecommendation): string {
  if (!recommendation || recommendation.products.length === 0) {
    return [
      'Thứ tự chuẩn là làm sạch trước, sau đó dưỡng ẩm hoặc làm dịu.',
      'Chỉ thêm bước bảo vệ ban ngày khi da đã quen routine cơ bản.',
      'Mỗi bước đợi lớp sản phẩm thấm nhẹ rồi mới sang bước tiếp theo.',
    ].join(' ')
  }

  const ordered = sortProductsByStep(recommendation.products)
  const steps = ordered
    .map((p, index) => `${index + 1}) ${STEP_LABELS[p.routineStep]} — ${p.name}`)
    .join('; ')

  return [
    `Thứ tự gợi ý: ${steps}.`,
    'Luôn làm sạch trước để da sẵn sàng hấp thụ bước dưỡng.',
    'Ban ngày kết thúc bằng kem chống nắng nếu routine có bước bảo vệ; ban đêm có thể bỏ qua.',
  ].join(' ')
}

function answerGenericFallback(
  skinResult: SkinAnalysisResult,
  recommendation?: RoutineRecommendation,
  goal?: SkinGoal,
): string {
  const skinLabel = getSkinTypeLabel(skinResult.skinType)
  const insight = skinResult.insight?.trim()
  const summary = recommendation?.summary
  const goalLabel = goal ? GOAL_LABELS[goal] : undefined

  return [
    insight
      ? `Dựa trên scan, ${skinLabel} — ${insight}`
      : `Dựa trên scan, tình trạng hiện tại phù hợp routine nhẹ, tập trung ${goalLabel ?? 'cân bằng da'}.`,
    summary ?? 'Routine Simple gợi ý giữ các bước tối giản để da làm quen dần.',
    'Bạn có thể chọn câu hỏi gợi ý bên dưới hoặc hỏi cụ thể về sản phẩm, thứ tự dùng hay combo tại Watson.',
  ].join(' ')
}

function matchTheme(
  normalized: string,
): 'oily_moisturizer' | 'single_product' | 'routine_timing' | 'sensitive' | 'combo' | 'order' | 'fallback' {
  const isOilyMoisturizer =
    (normalized.includes('dầu') || normalized.includes('da dầu')) &&
    (normalized.includes('kem dưỡng') ||
      normalized.includes('dưỡng ẩm') ||
      normalized.includes('moisturizer') ||
      normalized.includes('dùng kem'))

  if (isOilyMoisturizer) return 'oily_moisturizer'

  if (
    normalized.includes('1 sản phẩm') ||
    normalized.includes('một sản phẩm') ||
    normalized.includes('chỉ mua')
  ) {
    return 'single_product'
  }

  if (
    normalized.includes('sáng') ||
    normalized.includes('tối') ||
    normalized.includes('buổi sáng') ||
    normalized.includes('buổi tối') ||
    (normalized.includes('routine') && (normalized.includes('dùng') || normalized.includes('hay')))
  ) {
    return 'routine_timing'
  }

  if (normalized.includes('nhạy cảm') || normalized.includes('lưu ý')) {
    return 'sensitive'
  }

  if (
    normalized.includes('combo') ||
    normalized.includes('promo') ||
    normalized.includes('ưu đãi') ||
    normalized.includes('khuyến mãi')
  ) {
    return 'combo'
  }

  if (
    normalized.includes('thứ tự') ||
    normalized.includes('bước nào') ||
    normalized.includes('trước') ||
    normalized.includes('dùng sao') ||
    normalized.includes('thoa sao')
  ) {
    return 'order'
  }

  return 'fallback'
}

export function answerVietnameseQuestion(params: AnswerVietnameseQuestionParams): string {
  const { question, skinResult, recommendation, selectedGoal, selectedPreference } = params
  const normalized = normalizeQuestion(question)
  const theme = matchTheme(normalized)

  let answer: string

  switch (theme) {
    case 'oily_moisturizer':
      answer = answerOilyMoisturizer(skinResult, recommendation)
      break
    case 'single_product':
      answer = answerSingleProduct(skinResult, recommendation, selectedGoal)
      break
    case 'routine_timing':
      answer = answerRoutineTiming(recommendation)
      break
    case 'sensitive':
      answer = answerSensitiveCaution(skinResult, recommendation)
      break
    case 'combo':
      answer = answerComboPromo(recommendation, selectedPreference)
      break
    case 'order':
      answer = answerProductOrder(recommendation)
      break
    default:
      answer = answerGenericFallback(skinResult, recommendation, selectedGoal)
      break
  }

  if (hasSensitiveSignal(skinResult) && theme !== 'sensitive' && theme !== 'fallback') {
    answer = `${answer} Nếu da đang nhạy cảm, nên patch test trước khi dùng đều đặn.`
  }

  return sanitizeBeautyCopy(answer)
}
